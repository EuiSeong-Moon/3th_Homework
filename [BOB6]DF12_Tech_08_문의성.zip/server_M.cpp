#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <cstring>
int main(int argc, char **argv)
{
    struct sockaddr_in servaddr, cliaddr;
    int sockfd; // socket descripter
    int acc_sock;   // accept_socket
    socklen_t addrlen = sizeof(cliaddr);
int read_len, file_read_len;
char buf[1024];
int des_fd;
    if(argc < 2)
    {
        printf("Usage: %s port \n", argv[0]);
        return -1;
    }

    if((sockfd = socket(PF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Socket failed !");
        return -1;
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if(bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("bind failed !");
        return -1;
    }

    listen(sockfd, 3);
    while(1)
    {
	char file_name[1024];
        puts("Listening.....");
        acc_sock = accept(sockfd, (struct sockaddr*)&cliaddr,&addrlen);

        if(acc_sock < 0)
        {
            perror("accept failed !");
            return -1;
        }
        puts("Connected client");
	read_len=read(acc_sock,buf,1024);
	if(read_len>0)
{
	strcpy(file_name,buf);
}
else{
close(acc_sock);
break;
}
FILE_OPEN:
char ex[]=".txt";
des_fd=open(strcat(file_name,ex),O_WRONLY | O_CREAT | O_EXCL,0700);

if(!des_fd){
perror("file open error:");
break;
}
if(errno==EEXIST){
close(des_fd);
size_t len=strlen(file_name);
file_name[len++]='_';
file_name[len++]='n';
file_name[len]='\0';
goto FILE_OPEN;
}while(1){
memset(buf,0x00,1024);
file_read_len=read(acc_sock,buf,1024);
write(des_fd,buf,file_read_len);
if(file_read_len==EOF | file_read_len==0){
printf("finish file\n");
break;
}

    }
close(acc_sock);
close(des_fd);
}
    close(sockfd);
    return 0;
}
